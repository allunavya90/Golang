package main

import "fmt"

func main() {
fmt.Print("Hello world")
 fmt.Printf(" %s", "welcome  GoLang")
 var skill string = " i am junior developer "
 fmt.Println()
 fmt.Println(skill)
 skilll:= "welcome to golang pratice"
 fmt.Printf(skilll)
}
