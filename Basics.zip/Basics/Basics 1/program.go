package  main

import "fmt"

func main(){
var a = 1.0
var b = 2.0
var add float64 = a / b
 fmt.Printf("%g", add)
}

